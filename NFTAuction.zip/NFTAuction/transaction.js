class Transaction {
  constructor(sender, recipient, amount, timestamp, nftName, nftDescription, nftImageUrl) {
    this.sender = sender;
    this.recipient = recipient;
    this.amount = amount;
    this.timestamp = timestamp;
    this.nftName = nftName;
    this.nftDescription = nftDescription;
    this.nftImageUrl = nftImageUrl;
  }

  static createAuctionTransaction(sender, startingPrice, auctionEndTime, nftName, nftDescription, nftImageUrl) {
    const auctionTransaction = new Transaction(sender, 'auction', startingPrice, auctionEndTime, nftName, nftDescription, nftImageUrl);
    console.log('새로운 경매 트랜잭션 생성:', auctionTransaction);
    return auctionTransaction;
  }
}

module.exports = Transaction;
