const sha256Hash = require('./sha256Hash');
const Block = require('./Block');
const Transaction = require('./Transaction');

class Blockchain {
  constructor() {
    this.chain = [this.createGenesisBlock()];
    this.difficulty = 4;
    this.pendingTransactions = [];
  }

  createGenesisBlock() {
    console.log("제네시스 블록을 생성합니다.");
    return new Block(0, '0', 'genesis-hash', [], Date.now(), 0, []);
  }

  getLatestBlock() {
    return this.chain[this.chain.length - 1];
  }

  addBlock(block) {
    console.log("블록체인에 생성된 블록을 추가합니다.");
    // console.log(block);
    this.chain.push(block);
    this.pendingTransactions = [];
  }

  createBlock(transactions) {
    const index = this.chain.length;
    const previousHash = this.getLatestBlock().hash;
    const timestamp = Date.now();
    let nonce = 0;
    let hash = '';
    let auctionInfo = this.getLatestBlock().auctionInfo;

    const tran = transactions[0];
    if (index == 1) {
        auctionInfo = {
        isAuction : tran.recipient,
        startingPrice : tran.amount,
        auctionEndTime : tran.timestamp,
        highestBid : tran.amount,
        highestBidder : tran.sender,
      }
    } else {
      auctionInfo.highestBid = tran.amount;
      auctionInfo.highestBidder = tran.sender;
    }

    while (hash.substring(0, this.difficulty) !== Array(this.difficulty + 1).join('0')) {
      nonce++;
      hash = sha256Hash(index + previousHash + timestamp + JSON.stringify(transactions) + nonce);
    }
    
    const newBlock = new Block(index, previousHash, hash, transactions, timestamp, nonce, auctionInfo);
    console.log('새로운 블록 생성:', newBlock);
    return newBlock;
  }

  isChainValid() {
    for (let i = 1; i < this.chain.length; i++) {
      const currentBlock = this.chain[i];
      const previousBlock = this.chain[i - 1];

      if (!currentBlock.isValid()) {
        console.log(`Block #${currentBlock.index} has an invalid hash.`);
        return false;
      }

      if (currentBlock.previousHash !== previousBlock.hash) {
        console.log(`Blockchain is broken at Block #${currentBlock.index}.`);
        return false;
      }
    }

    console.log('Blockchain is valid.');
    return true;
  }

  // 경매 생성 트랜잭션 추가 메서드
  addAuctionTransaction(sender, startingPrice, auctionEndTime, nftName, nftDescription, nftImageUrl) {
    const auctionTransaction = Transaction.createAuctionTransaction(sender, startingPrice, auctionEndTime, nftName, nftDescription, nftImageUrl);
    this.pendingTransactions.push(auctionTransaction);
    return this.getLatestBlock().index + 1;
  }

/*   // 경매 트랜잭션의 유효성 검증
  validateAuctionTransaction(transaction) {
    if (transaction.recipient !== 'auction') {
      return false;
    }
    // 경매 트랜잭션에 대한 추가 유효성 검사 로직을 추가할 수 있습니다.
    // (e.g., 유효한 시간 내에 생성되었는지, 현재 경매 중인지 등)
    return true;
  } */
}

module.exports = Blockchain;
