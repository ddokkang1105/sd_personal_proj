const sha256Hash = require('./sha256Hash');

class Block {
  // 새로운 필드 추가
  // 경매 정보는 다음과 같은 형태로 저장될 수 있습니다.
  // auctionInfo: { isAuction: boolean, startingPrice: number, auctionEndTime: number, highestBid: number, highestBidder: string }
  constructor(index, previousHash, hash, transactions, timestamp, nonce, auctionInfo) {
    this.index = index;
    this.previousHash = previousHash;
    this.hash = hash;
    this.transactions = transactions;
    this.timestamp = timestamp;
    this.nonce = nonce;
    this.auctionInfo = auctionInfo; // 경매 정보
  }

  calculateHash() {
    const data = this.index + this.previousHash + this.timestamp + JSON.stringify(this.transactions) + this.nonce;
    const hash = sha256Hash(data);
    console.log(`Block #${this.index}의 해시값: ${hash}`);
    return hash;
  }

  isValid() {
    if (this.hash !== this.calculateHash()) {
      console.log(`Invalid hash for Block #${this.index}`);
      return false;
    }
    return true;
  }

  // 새로운 메서드 추가: 경매 정보 갱신
  updateAuctionInfo(isAuction, startingPrice, auctionEndTime, highestBid, highestBidder) {
    this.auctionInfo = {
      isAuction,
      startingPrice,
      auctionEndTime,
      highestBid,
      highestBidder,
    };
  }
}

module.exports = Block;
