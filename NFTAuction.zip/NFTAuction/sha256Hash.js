const crypto = require('crypto');

function sha256Hash(data) {
  const hash = crypto.createHash('sha256').update(data, 'utf8').digest('hex');
  return hash;
}

module.exports = sha256Hash;
