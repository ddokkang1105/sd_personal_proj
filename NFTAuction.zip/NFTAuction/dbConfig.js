const mysql = require('mysql');

const connection = mysql.createConnection({
    host: '34.134.149.202',
    user: 'ddadmin',
    password: '1q2w3e4r!',
    database: 'ddobot_db',
  });

// 데이터베이스 연결
connection.connect((err) => {
    if (err) {
      console.error('데이터베이스에 연결할 수 없습니다:', err);
      return;
    }
    console.log('데이터베이스에 성공적으로 연결되었습니다!');
  });

module.exports = connection;