const express = require('express');
const path = require('path');
const router = express.Router();

// 데이터베이스 연결 설정 (dbConfig 모듈 가져오기)
const connection = require('./dbConfig');

// 루트 경로에 대한 응답 처리
router.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

router.post('/user.regist/', async (req, res) => {
    const userData = req.body;
    // console.log("전달받은 유저 데이터 : ", userData);

    try {
      const rows = await new Promise((resolve, reject) => {
        connection.query('SELECT * FROM soldesk_user_gcp where u_email = ?', userData.u_email, (err, rows) => {
          if (err) reject(err);
          resolve(rows);
        });
      });

      if (rows.length === 0) {
        connection.query('INSERT INTO soldesk_user_gcp SET ?', userData, (err, result) => {
          if (err) {
            console.error('데이터베이스 오류:', err);
            return res.status(500).send('데이터베이스 오류');
          }

          console.log('새로운 유저가 추가되었습니다.');

          // 회원 등록이 성공하면 JSON 응답으로 "success"를 보냅니다.
          res.json({ message: 'success' });
        });
      } else {
        console.log('이미 존재하는 유저입니다.');

        res.json({ message: 'success' });
      }
    } catch (error) {
        console.error('데이터베이스 오류:', error);
        res.status(500).json({ message: '데이터베이스 오류' });
        res.json({ message: 'Fail' });
    }
});

router.get('/nft.get', (req, res) => {
    const nftData = req.query;
    // console.log("전달받은 유저 데이터 : ", nftData);
    res.sendFile(path.join(__dirname, 'public', 'wallet.html'));
});

router.get('/auction.go', (req, res) => {
    const key = req.query.key;

    const fs = require('fs');
    fs.readFile(path.join(__dirname, 'public', 'wallet.html'), 'utf8', (err, data) => {
      if (err) {
        console.error('파일 읽기 오류:', err);
        return res.status(500).send('파일 읽기 오류');
      }
      // 데이터 치환
      const modifiedData = data.replace(/\${key}/g, key);
      // 수정된 데이터 클라이언트에게 전달
      res.send(modifiedData);
    });
});

router.get('/user.getWallet', (req, res) => {
    const u_public_key = req.query.u_public_key;
    // console.log(u_public_key);
  
    connection.query('SELECT * FROM soldesk_user_gcp WHERE u_public_key = ?', u_public_key, (err, result) => {
      if (err) {
        console.error('데이터베이스 오류:', err);
        return res.status(500).send('데이터베이스 오류');
      } else {
        // console.log(result);
        res.json(result);
      }
    });
});

router.get('/nft.auction.go', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'auction.html'));
});

router.post('/nft.regist', async (req, res) => {
    const nftData = req.body;
    // console.log("전달받은 유저 데이터 : ", nftData);
  
    connection.query('INSERT INTO soldesk_nft_gcp SET ?', nftData, (err, result) => {
      if (err) {
        console.error('데이터베이스 오류:', err);
        return res.status(500).send('데이터베이스 오류');
      }
  
      console.log('새로운 NFT가 추가되었습니다.');
  
      // NFT 등록이 성공하면 JSON 응답으로 "success"를 보냅니다.
      res.json({ message: 'success' });
    });
});

router.get('/nft.getRegistList', (req, res) => {

  connection.query('SELECT * FROM soldesk_nft_gcp WHERE n_status = 1', (err, result) => {
    if (err) {
      console.error('데이터베이스 오류:', err);
      return res.status(500).send('데이터베이스 오류');
    } else {
      // console.log(result);
      res.json(result);
    }
  });
});

router.get('/nft.getAuctionList', (req, res) => {

  connection.query('SELECT * FROM soldesk_nft_gcp WHERE n_status = 2', (err, result) => {
    if (err) {
      console.error('데이터베이스 오류:', err);
      return res.status(500).send('데이터베이스 오류');
    } else {
      // console.log(result);
      res.json(result);
    }
  });
});

router.get('/get.allTran', (req, res) => {
  const t_nftDescription = req.query.t_nftDescription;

  connection.query(`SELECT * FROM soldesk_transaction_gcp WHERE t_nftDescription = '${t_nftDescription}' and t_startingPrice > 0`, (err, result) => {
    if (err) {
      console.error('데이터베이스 오류:', err);
      return res.status(500).send('데이터베이스 오류');
    } else {
      res.json(result);
    }
  });
});

router.get('/tran.getLastestPrice', (req, res) => {
  let t_nftDescription = req.query.t_nftDescription;

  connection.query(`SELECT * FROM soldesk_transaction_gcp WHERE t_nftDescription = '${t_nftDescription}' and ` +
                    `t_b_no = ( select max(t_b_no) from soldesk_transaction_gcp where t_nftDescription = '${t_nftDescription}' ` +
                    `and t_startingPrice > 0 ) `, (err, result) => {
    if (err) {
      console.error('데이터베이스 오류:', err);
      return res.status(500).send('데이터베이스 오류');
    } else {
      res.json(result);
    }
  });
})

router.get('/tran.lastestNo', (req, res) => {
  let t_nftDescription = req.query.t_nftDescription;

  connection.query('SELECT max(t_b_no) FROM soldesk_transaction_gcp WHERE t_nftDescription = ?', t_nftDescription, (err, result) => {
    if (err) {
      console.error('데이터베이스 오류:', err);
      return res.status(500).send('데이터베이스 오류');
    } else {
      const latestNo = result[0]['max(t_b_no)'];
      res.send(String(latestNo));
    }
  });
})

router.get('/tran.getAuctionTime', (req, res) => {
  let t_nftDescription = req.query.t_nftDescription;

  connection.query('SELECT t_auctionEndTime FROM soldesk_transaction_gcp WHERE t_b_no = 1 and t_nftDescription = ?', t_nftDescription, (err, result) => {
    if (err) {
      console.error('데이터베이스 오류:', err);
      return res.status(500).send('데이터베이스 오류');
    } else {
      const endTime = result[0]['t_auctionEndTime'];
      res.send(String(endTime));
    }
  });
});

router.get('/tran.isBidded', async (req, res) => {
  let sender = req.query.t_sender;
  let nftDescription = req.query.t_nftDescription;

  try {
    const result = await new Promise((resolve, reject) => {
      connection.query(`SELECT t_startingPrice FROM soldesk_transaction_gcp where t_sender = '${sender}' ` + 
      `and t_nftDescription = '${nftDescription}' and t_b_no = ( select max(t_b_no) ` + 
      `from soldesk_transaction_gcp where t_sender = '${sender}' and t_nftDescription = '${nftDescription}' )`, (err, result) => {
        if (err) {
          console.error('데이터베이스 오류:', err);
          reject('데이터베이스 오류');
        } else {
          resolve(result);
        }
      });
    });

    // console.log("result : ", result);
    if (result[0]['t_startingPrice'] === null) {
      // console.log("경매 기록 X");
      res.send(String(0));
    } else {
      const biddedPrice = result[0]['t_startingPrice'];
      res.send(String(biddedPrice));
    }
  } catch (error) {
    res.status(500).send(error);
  }
});

router.post('/bid.userCash', async (req, res) => {
  const bidData = req.body;
  // console.log(bidData.u_email);
  // console.log(bidData.u_wallet_cash);

  connection.query(`UPDATE soldesk_user_gcp set u_wallet_cash = ${bidData.u_wallet_cash} where u_email = '${bidData.u_email}'`, (err, result) => {
    if (err) {
      console.error('데이터베이스 오류:', err);
      return res.status(500).send('데이터베이스 오류');
    } else {
      console.log("유저 지갑이 변동되었습니다.");
    }
  });

  res.json({ message: 'success' });
});

module.exports = router;
