const express = require('express');
const path = require('path');
// 자바 컨트롤러 보안 정책
const cors = require('cors');
// 자바 컨트롤러로 이동할 때
const axios = require('axios');

const app = express();
const bodyParser = require('body-parser');
const auctionRouter = require('./auctionRouter');
const port = 3000;

// 데이터베이스 연결 설정
const connection = require('./dbConfig');

// 라우터 가져오기
const router = require('./router');

// 정적 파일을 제공하기 위한 미들웨어 설정
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended : true }));
app.use(cors());

// 라우터 설정
app.use(router);
app.use('/auction', auctionRouter);

app.listen(port, () => {
  console.log(`서버가 http://localhost:${port} 에서 실행 중입니다.`);
});

