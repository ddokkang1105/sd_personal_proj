const express = require('express');
const router = express.Router();
const Blockchain = require('./Blockchain');

const connection = require('./dbConfig');

let blockchain = null;

// 경매 생성 엔드포인트
router.post('/create', (req, res) => {
  blockchain = new Blockchain();
  const auctionData = req.body;
  const status = auctionData.status;
  // gcp db에 nft 상태 변경하는 코드
  connection.query(`UPDATE soldesk_nft_gcp SET n_status = ${status + 1} where n_hash = '${auctionData.nftDescription}'`, (err, result) => {
    if (err) {
      console.error('데이터베이스 오류:', err);
      return res.status(500).send('데이터베이스 오류');
    }

    console.log("NFT가 경매에 등록되었습니다.");
  });

  const tranData = {
    sender : auctionData.sender,
    startingPrice : auctionData.startingPrice,
    auctionEndTime : auctionData.auctionEndTime,
    nftName : auctionData.nftName,
    nftDescription : auctionData.nftDescription,
    nftImageUrl : auctionData.nftImageUrl,
  };
  
  // 새로운 경매 트랜잭션 생성 및 추가
  const blockIndex = blockchain.addAuctionTransaction(tranData.sender, tranData.startingPrice, tranData.auctionEndTime, tranData.nftName, tranData.nftDescription, tranData.nftImageUrl);
  console.log('새로운 경매 트랜잭션 추가. 블록 인덱스:', blockIndex);

  const sqlData = {
    t_sender : tranData.sender,
    t_startingPrice : tranData.startingPrice,
    t_auctionEndTime : tranData.auctionEndTime,
    t_nftName : tranData.nftName,
    t_nftDescription : tranData.nftDescription,
    t_nftImageUrl : tranData.nftImageUrl,
    t_b_no : 1,
  };

  connection.query(`SELECT * FROM soldesk_transaction_gcp WHERE t_nftDescription = '${sqlData.t_nftDescription}'`, (err, result) => {
    if (err) {
      console.error('데이터베이스 오류:', err);
      return res.status(500).send('데이터베이스 오류');
    } else {
      if (result == "") {
        connection.query('INSERT INTO soldesk_transaction_gcp SET ?', sqlData, (err, result) => {
          if (err) {
            console.error('데이터베이스 오류:', err);
            return res.status(500).send('데이터베이스 오류');
          }

          console.log("Transaction이 DB에 등록되었습니다.");
        });
      } else {
        console.log("이미 경매에 등록되어 있습니다.");
      }

    }
  });


  res.json({ message: 'success' });
});

router.post('/addAuctionBlock', (req, res) => {
  if (blockchain.isChainValid()) {
    blockchain.addBlock(blockchain.createBlock(blockchain.pendingTransactions));
    console.log(blockchain.getLatestBlock());
  }
});


router.post('/bid', (req, res) => {
  let now_tranData = req.body;
  
  let tranData = null;
  
  connection.query(`SELECT * FROM soldesk_transaction_gcp WHERE t_nftDescription = '${now_tranData.nftDescription}' order by t_b_no`, (err, result) => {
    if (err) {
      console.error('데이터베이스 오류:', err);
      return res.status(500).send('데이터베이스 오류');
    } else {
      blockchain = new Blockchain();
      
      let currentArray = null;
      console.log("result : ", result);
      for (let i = 0; i < result.length; i++) {
        currentArray = result[i];
        tranData = {
          sender : currentArray.t_sender,
          startingPrice : currentArray.t_startingPrice,
          auctionEndTime : currentArray.t_auctionEndTime,
          nftName : currentArray.t_nftName,
          nftDescription : currentArray.t_nftDescription,
          nftImageUrl : currentArray.t_nftImageUrl,
        };
        
        const blockIndex = blockchain.addAuctionTransaction(tranData.sender, tranData.startingPrice, tranData.auctionEndTime, tranData.nftName, tranData.nftDescription, tranData.nftImageUrl);
        console.log('새로운 경매 트랜잭션 추가. 블록 인덱스:', blockIndex);
        
        if (blockchain.isChainValid()) {
          blockchain.addBlock(blockchain.createBlock(blockchain.pendingTransactions));
        }
        
      }
      
        tranData = {
          sender : now_tranData.sender,
          startingPrice : now_tranData.startingPrice,
          auctionEndTime : now_tranData.auctionEndTime,
          nftName : now_tranData.nftName,
          nftDescription : now_tranData.nftDescription,
          nftImageUrl : now_tranData.nftImageUrl,
        };
      
        const blockIndex = blockchain.addAuctionTransaction(tranData.sender, tranData.startingPrice, tranData.auctionEndTime, tranData.nftName, tranData.nftDescription, tranData.nftImageUrl);
        console.log('새로운 경매 트랜잭션 추가. 블록 인덱스:', blockIndex);
      
        if (blockchain.isChainValid()) {
          blockchain.addBlock(blockchain.createBlock(blockchain.pendingTransactions));
        }
      
        console.log("블록체인화 마지막 블록 : ", blockchain.getLatestBlock());
    }
  });
  
  
  const sqlData = {
    t_sender : now_tranData.sender,
    t_startingPrice : now_tranData.startingPrice,
    t_auctionEndTime : now_tranData.auctionEndTime,
    t_nftName : now_tranData.nftName,
    t_nftDescription : now_tranData.nftDescription,
    t_nftImageUrl : now_tranData.nftImageUrl,
    t_b_no : now_tranData.t_b_no,
  };
  
  connection.query('INSERT INTO soldesk_transaction_gcp SET ?', sqlData, (err, result) => {
    if (err) {
      console.error('데이터베이스 오류:', err);
      return res.status(500).send('데이터베이스 오류');
    }
    
    console.log("새로운 Transaction이 DB에 등록되었습니다.");
  });
  
  
  res.json({ message: 'success' });
});

// router.get()

module.exports = router;

/* // 경매 입찰 엔드포인트
router.post('/bid', (req, res) => {
  const { bidder, bidAmount, blockIndex } = req.body;
  const block = blockchain.chain[blockIndex];

  if (!block || !block.auctionInfo || !block.auctionInfo.isAuction) {
    return res.status(400).json({ message: '유효하지 않은 경매 블록 인덱스 또는 경매를 찾을 수 없습니다.' });
  }

  if (bidAmount <= block.auctionInfo.highestBid) {
    return res.status(400).json({ message: '입찰 금액은 현재 최고 입찰액보다 높아야 합니다.' });
  }

  // 새로운 경매 트랜잭션 생성 및 추가
  const auctionTransaction = new Transaction(bidder, 'auction', bidAmount, Date.now());
  blockchain.pendingTransactions.push(auctionTransaction);
  console.log('새로운 경매 입찰 트랜잭션 추가:', auctionTransaction);

  // 경매 정보 갱신
  block.updateAuctionInfo(true, block.auctionInfo.startingPrice, block.auctionInfo.auctionEndTime, bidAmount, bidder);

  res.json({ message: 'success' });
}); */