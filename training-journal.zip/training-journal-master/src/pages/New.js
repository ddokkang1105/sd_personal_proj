import { useEffect } from 'react';
import DiaryEditor from '../components/DiaryEditor';

const New = () => {
  useEffect(() => {
    const titleElement = document.getElementsByTagName('title')[0];
    titleElement.innerHTML = `운동 일지 - 새 일지`;
  }, []);

  return (
    <div>
      <DiaryEditor />
    </div>
  );
};

export default New;
